

#include <iostream>
using namespace std;
const int r=2;
const int c=2;

//sum of all values;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

int getTotal(int array[r][c],int r,int c)
{
	
int i=0;
int j=0;
int sum=0;
	for (i=0; i<r; i++)
	{
		for (j=0; j<c ;j++)
		{
			cin>>array[i][j];
			sum=sum+array[i][j];
		}
	}
	
return sum;

}


//average of all elements;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

float getAverage(int array[r][c],int r,int c)
{
	
int i=0;
int j=0;
int sum=0;
float average;
	for (i=0; i<r; i++)
	{
		for (j=0; j<c ;j++)
		{
			cin>>array[i][j];
			sum=sum+array[i][j];
		}
	}
	average=float(sum)/(r*c);
return average;

}

//specified row total;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


int getrowtotal(int array[r][c],int r,int c,int choice)
{
	
int i=0;
int j=0;
int sum=0;

	

	for (i=0; i<r; i++)
	{
		for (j=0; j<c ;j++)
		{
			cin>>array[i][j];
			sum=sum+array[i][j];
		}
	}


	
	if (choice==0 )
	{
		sum=array[0][0]+array[0][1];
	}
		
	if (choice==1 )
	{
		sum=array[1][0]+array[1][1];
	}	


return sum;

}

//specified colomun  total;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


int getcolumntotal(int array[r][c],int r,int c,int choice1)
{
	
int i=0;
int j=0;
int sum=0;

	

	for (i=0; i<r; i++)
	{
		for (j=0; j<c ;j++)
		{
			cin>>array[i][j];
			sum=sum+array[i][j];
		}
	}


	
	if (choice1==0 )
	{
		sum=array[0][0]+array[1][0];
	}
		
	if (choice1==1 )
	{
		sum=array[0][1]+array[1][1];
	}	


return sum;

}















//main function;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

int main()
{
	
	int array[2][2];
	int sum=getTotal(array,r,c);
	float average=getAverage(array,r,c);
	int choice;
	cout<<"Enter your choice for row" <<endl;
	cin>>choice;
	int choice1;
	cout<<"Enter your choice for columun" <<endl;
	cin>>choice1;
	
	int ct=getcolumntotal(array,r,c,choice1);
	int rt=getrowtotal(array,r,c,choice);
	cout<<"Sum of specified Row"<<rt<<endl;
	cout<<"Sum of specified Colomun "<<ct<<endl;
	cout<<"Sum of elements "<<sum<<endl;

	cout<<"Average "<<average <<endl;
}
