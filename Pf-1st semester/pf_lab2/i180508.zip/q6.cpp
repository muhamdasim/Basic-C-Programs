



#include <iostream>
using namespace std ;

int main ()

{

int d,y,m ;
int eq,eq1,eq2;



cout <<"enter Month: \n " ;
cin >> m;

cout <<"Enter date: \n" ;
cin >> d;

cout <<"Enter year: \n";
cin >> y;

eq=6;
eq1=10;
eq2=1960;

if (m==eq and d==eq1 and y==eq2 )

{

cout <<"Date is magic" ;

}

else

{

cout <<"not magic" ;
}


return 0;



}



