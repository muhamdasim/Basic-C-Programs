
#include <iostream>
using namespace std ;

int main ()

{

float h;

cout <<"Enter height: \n" ;

cin >>h;

if (h<5)

{

cout <<"Height is smaller" ;

}

if (h>6.2)

{

cout <<"Height is large" ;

}

if (h>5 and h<6.2 )
{
cout <<"Height is medium" ;

}


return 0;

}
