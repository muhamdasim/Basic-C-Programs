

#include <iostream>
using namespace std ;

int main ()

{

int t;

cout <<"Enter temperature: " ;
cin >> t;

if (t<23)

{

cout <<"Room is cold" ;

}

if (t==23 or t>23)

{

cout <<"Room is hot" ;

}

return 0;


}

