

#include <iostream>
using namespace std ;

int main ()

{

int x;

cout <<"Enter number: \n" ;
cin >> x;

if (x<1 or x>10 )

{

cout <<"Invalid input" ;

}

else 
if (x==1)

{

cout <<"Roman numeral version is: " << "I" ;

}

if (x==2)

{

cout <<"Roman numeral version is: " << "II" ;

}

if (x==3)

{

cout <<"Roman numeral version is: " << "III" ;

}

if (x==4)

{

cout <<"Roman numeral version is: " << "IV" ;

}

if (x==5)

{

cout <<"Roman numeral version is: " << "V" ;

}

if (x==6)

{

cout <<"Roman numeral version is: " << "VI" ;

}

if (x==7)

{

cout <<"Roman numeral version is: " << "VII" ;

}

if (x==8)

{

cout <<"Roman numeral version is: " << "VIII" ;

}

if (x==9)

{

cout <<"Roman numeral version is: " << "IX" ;

}

if (x==10)

{

cout <<"Roman numeral version is: " << "X" ;

}

return 0;

}
