



#include <iostream>
using namespace std ;

int main ()

{

int x,y ;

cout <<"Enter First no: \n" ;
cin >>x;


cout<<"Enter second no: \n" ;

cin>>y;


if (x==y)

{

cout << "Numbers are equal" ;

}

if (x>y) 

{

cout <<"Larger no is: " << x ;

}

else

{

cout <<"Larger no is: " <<y;

}

return 0;

}



