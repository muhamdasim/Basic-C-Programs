
#include <iostream>
using namespace std;
int main()
{

int x = 5;
int y = 3;
int result = 1;
for(int i = 0; i < y; ++i)
{
    result *= (result / (1/result)) ;
}

cout << result << endl;



return 0;

}
