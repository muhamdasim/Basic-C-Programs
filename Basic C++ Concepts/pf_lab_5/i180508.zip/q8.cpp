Write a program in C++ that takes number from user, create and display unique three-digit number
using 1, 2, 3, 4.(given n as 4) Also count how many three-digit numbers are there. Sample Output:
The three-digit numbers are: 123, 124, 132, 134, 142, 143, 213, 214, 231, 234, 241, 243, 312, 314, 321, 324,
341, 342, 412, 413, 421, 423, 431, 432
Total number of the three-digit-number is: 24		


