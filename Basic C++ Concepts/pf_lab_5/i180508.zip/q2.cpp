#include <iostream>
using namespace std;
int main()
	{
	int n;
	cout <<"Enter no" <<endl;
	cin >>n;

	int i=1;
	int j=1;


	for (i=1 ; i<=n ; i++ )
	{
	for (j=1 ; j<=n ; j++)
	{
		cout <<j;
	}
		cout <<endl;

	}
	cout <<i;
	
	return 0;
}
