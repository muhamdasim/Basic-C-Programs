#include <iostream>
using namespace std;
int main()
{
	int array[100][100];
	int n;
	cout <<"Enter size of matrix " <<endl;
	cin >> n;
	
	int i=0 ; int j=0;
	int check;
	for (i=0 ; i<n ; i++)
	{
		for (j=0 ; j<n ; j++)		
		{	
			cin >>array[i][j];
		}
	}
	
	for (i=0 ; i<n ; i++)
	{
		for (j=0 ; j<n ; j++)		
		{
			if(j<i && array[i][j]!=0)
			{
				check=0;
			}
		}
	}
		
	if (check==0 )
	
	{
		cout <<"Upper Traingle " <<endl;
			
		for (i=0 ; i<n ; i++)
		{
			for (j=0 ; j<n ; j++)		
			{
				cout << array[i][j] << " " ;
			}
			cout <<endl;
		}
	}
else
cout <<"Lower " ;

}
		
		
	
