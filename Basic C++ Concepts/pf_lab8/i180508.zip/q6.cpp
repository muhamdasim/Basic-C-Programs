#include <iostream>
using namespace std;
int main()
{	
	int array[20][20];
	int n;
	cout <<"Enter size of matrix"<<endl;
	cin>>n;
	int i=0;
	int j=0;
	int prime[20*20];
	int k=0;
	int count=0;
	
	for (i=0 ; i<n ; i++)
	{
		for (j=0 ; j<n ; j++)
		{
			cin>>array[i][j];
		}
	}
	
	for (i=0 ; i<n ; i++)
	{
		for (j=0 ; j<n ; j++)
		{
			for (i=2 ; i<array[i][j] ; i++)
			{
				if (array[i][j]%i==0)
				{
					break;
				}
			}
			if (array[i][j]==i)
			{
				cout <<"Prime";
			}
		}
	}

	}
