#include <iostream> 
using namespace std;

int main ()

{


float w,h,a;

cout << "Enter your width: \n" ;
cin >> w;

cout << "Enter your height: \n" ;

cin >> h;

a=h*w ;

cout << "Area is:" << a;

return 0;

}

