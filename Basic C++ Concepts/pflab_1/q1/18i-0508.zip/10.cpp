#include <iostream>
using namespace std;

int main ()

{

int a,a1,l ;


a=43560 ;

a1= 391876 ;

l=a1/a ;

cout << "Number of acre " << l ;

return 0;

}

