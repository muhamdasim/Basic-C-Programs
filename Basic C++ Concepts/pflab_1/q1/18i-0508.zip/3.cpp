#include <iostream>

using namespace std;

int main ()

{

 float f, b,e,c;

  cout << "Enter your temperature in Farenheit\n" ;

 cin >> f;



b=f-32 ;
e=b/9 ;
 c=e*5 ; 


cout << "Your Temperature in Celcius " <<c ;

return 0;

}


