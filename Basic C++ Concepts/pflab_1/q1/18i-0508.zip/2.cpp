#include <iostream>

using namespace std;

int main ()

{

 float c,x,f ;

  cout << "Enter your temperature in Centigrade\n" ;

 cin >> c;

 x=c*1.8 ;

f= x+32 ;

cout << "Your Temperature in Farenheit " <<f ;

return 0;

}


