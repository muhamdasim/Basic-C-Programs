#include <iostream>
using namespace std;

int main ()

{

   cout << "Name: Muhammad Asim\n" << "Address ,with city, state, and zipcode:House no 4 , block D,Gracy Lines , Rawalpindi , punjab 46000\n" << "Telephone no: 03344348826\n" << "College major: CS\n" ;

return 0;

}
