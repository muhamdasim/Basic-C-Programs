#include <iostream>
using namespace std;
int main ()

{

float r,c ;

cout << "Enter your radius " ;
cin >> r;
c= 2*22.414*r ;

cout << "Circumfrence is:" << c;

return 0;

}


