#include <iostream>
using namespace std ;
int main ()

{

float r,h,v;

cout << "Enter radius\n " ;
cin >> r ;

cout << "Enter height\n " ;
cin >> h;

v=22.414*r*r*h ;

cout << "Volume of cylinder is:" << v;

return 0;

}
