#include <iostream>
using namespace std ;

int main ()

{

float r,a;

cout << "Enter radius \n " ;

cin >> r ;

a=3.14*r*r ;

cout << "Area is:" << a;

return 0;

}


