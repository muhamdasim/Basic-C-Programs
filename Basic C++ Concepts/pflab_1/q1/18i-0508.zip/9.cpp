#include <iostream>
using namespace std ;

int main ()

{

float x,y,p,g ;

cout << "Enter x\n" ;
cin >> x;

cout << "Enter y\n" ;
cin >> y;

g=x/100 ;
p=g*y ;

cout << "x percent of y " << p ;

return 0;

}
