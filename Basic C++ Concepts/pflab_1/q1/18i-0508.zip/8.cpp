#include <iostream>

using namespace std ;

int main ()

{

float t,o,x,p ;

cout << "Enter total marks \n" ;
cin >> t;

cout << "Enter obtained marks\n" ;
cin >> o ;

x= o/t ;

p=x*100 ;

cout << "Percentage is" <<p ;

return 0;

}

