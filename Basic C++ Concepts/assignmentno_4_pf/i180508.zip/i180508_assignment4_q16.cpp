6a+9b+20c=n

#include <iostream>
using namespace std;
int main()
{

int pkr;
cout <<"Enter PKR " <<endl;
cin >> pkr;

float


