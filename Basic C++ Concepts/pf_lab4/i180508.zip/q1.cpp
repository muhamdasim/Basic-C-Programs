#include <iostream>
using namespace std;
int main()
{

int n;
cout <<"Enter no " ;
cin >> n;

char c ;
cout <<"Enter charachter " ;
cin >>c ;

int counter=1;

while (counter<=n)

{

cout <<"Output: " << c <<endl ;
counter=counter +1 ;


}

return 0;

}
