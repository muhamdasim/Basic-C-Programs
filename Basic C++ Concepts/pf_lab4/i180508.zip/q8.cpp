

#include <iostream>
using namespace std;
int main()
{

int n;
cout <<"Enter no" ;
cin >> n;
while (n!=99)
{
cout <<"Enter no" ;
cin >> n;


while (n==99 )

goto outloop;
}

}
outloop:

return 0;

}+
