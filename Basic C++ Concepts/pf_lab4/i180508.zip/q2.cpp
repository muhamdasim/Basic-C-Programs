#include <iostream>
using namespace std;
int main ()
	{
	int n,counter=1 ;
	cout <<"Enter no" ;
	cin >> n;

	while (counter<=n )

	{
		cout << counter <<"," ;

		counter=counter+1 ;

	}

	return 0;	

}
